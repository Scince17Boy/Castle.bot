const settings = {
  packname: 'Castle-Bot',
  author: '‎',
  botName: "Castle-Bot",
  botOwner: '𝓜𝓻. 𝓜𝓐𝓝𝓞𝓙', // Your name
  ownerNumber: '91836772367', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.2.2",
  updateZipUrl: "https://github.com/Scince17Boy/Kaira-Bot/archive/refs/heads/main.zip",
};

module.exports = settings;
